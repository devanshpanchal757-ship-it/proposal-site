const noBtn = document.getElementById("no");
noBtn.addEventListener("mouseover",()=>{
  noBtn.style.position="absolute";
  noBtn.style.left=Math.random()*80+"%";
  noBtn.style.top=Math.random()*80+"%";
});
document.getElementById("yes").onclick=()=>{
  document.body.innerHTML="<h1 style='color:#ff4d6d'>YAYYYY 💖🎉</h1>";
};
